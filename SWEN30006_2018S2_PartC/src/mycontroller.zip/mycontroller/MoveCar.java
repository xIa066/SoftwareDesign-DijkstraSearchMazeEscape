package mycontroller;

import controller.CarController;
import world.Car;

public class MoveCar extends MyAIController{

	public MoveCar(Car car) {
		super(car);
		// TODO Auto-generated constructor stub
	}

}
